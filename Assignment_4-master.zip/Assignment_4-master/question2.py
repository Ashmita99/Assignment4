tuple1 = (1, 2,3,4,5,6,7,8)
print('Max element in tuple==' + str(max(tuple1)))
print('Min element in tuple==' + str(min(tuple1)))